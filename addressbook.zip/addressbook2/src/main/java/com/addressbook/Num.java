package com.addressbook;

class Num {
	private String val;

	public Num(String x) 
	{
		this.val = x;
	}
	
		public String getNumber() 
			{
				return val;
			}
		
}
