package com.addressbook;

public class AddressDbTest {

}
